//
//  Check.swift
//  demo123
//
//  Created by Joechiao on 2021/5/26.
//

import Foundation
import FirebaseFirestoreSwift


struct Check: Codable, Identifiable {
    @DocumentID var id: String?
    let name: String
    let finish: String
    let date: Date
}
