//
//  demo123App.swift
//  demo123
//
//  Created by Joechiao on 2021/5/24.
//

import SwiftUI

@main
struct demo123App: App {
    @UIApplicationDelegateAdaptor(AppDelegate.self) var delegate
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
