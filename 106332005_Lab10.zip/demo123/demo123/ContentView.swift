//
//  ContentView.swift
//  demo123
//
//  Created by Joechiao on 2021/5/24.
//

import SwiftUI
import FirebaseFirestore
import FirebaseStorageSwift

struct ContentView: View {
    @State var data = [Check]()
    @State var inputName = ""
    @State var inputFinish =  ""
    @State var inputDate = Date()
    @State var getName = "無"
    @State var getFinish = "無"
    @State var getDate = Date()
//
    func createData(){
        
        let db = Firestore.firestore()

        let data = Check(name: inputName, finish: inputFinish, date: inputDate)
        do{
            let documentReference = try
                db.collection("ToDoApp").addDocument(from: data)
        } catch{
            print(error)
        }
    }

    func fetchData() {
       
        let db = Firestore.firestore()
        db.collection("ToDoApp").whereField("name", isEqualTo: inputName).getDocuments{ snapshot, error in
                
             guard let snapshot = snapshot else { return }
            
             let data = snapshot.documents.compactMap { snapshot in
                 try? snapshot.data(as: Check.self)
            
             
                
             }
            print(data)
            let showData = data[0]
            getName = showData.name
            getFinish = showData.finish
            getDate = showData.date
         }
    }
    
    var body: some View {
        
    
        VStack {
            HStack {
                VStack(alignment: .leading, spacing: 50){
                    Text("名稱: ")
                    Text("是否完成: ")
                    Text("到期時間: ")
                }
                .padding()
                VStack (alignment: .trailing, spacing: 50){
                    TextField("請輸入名稱", text: $inputName)
                    TextField("請輸入是或否", text: $inputFinish)
                    DatePicker("", selection: $inputDate)
                }
                .padding()
            }
            VStack (alignment: .center, spacing: 10){
                Button(action: {
                    createData()
                }
                       , label: {
                    Text("新增數據")
                })
                Text("---------------------------------------------")
                Button(action: {
                    fetchData()
                }
                , label: {
                    Text("讀取數據")
                })
                HStack {
                    VStack (alignment: .leading, spacing: 50){
                        Text("名稱: ")
                        Text("是否完成: ")
                        Text("到期時間: ")
                    }
                    VStack(alignment: .center, spacing: 50) {
                        Text("\(getName)")
                        Text("\(getFinish)")
                        Text("\(getDate)")
                    
                    }
                   
                }
                
            }
            
        }
        
        
            
        
           
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
