//
//  ContentView.swift
//  demo2
//
//  Created by Joechiao on 2021/5/3.
//

import SwiftUI

struct ContentView: View {
//    @State private var showWiki = false
//    @State private var showMon = false
    var body: some View {
        
        NavigationView {
            VStack {
                Image("MHR_image")
                    .resizable()
                    .scaledToFit()
                NavigationLink(
                    destination: game_wiki(),
                    label: {
                        Text("遊戲介紹")
                    })
                    
                NavigationLink(
                    destination: monsters_list(),
                    label: {
                        Text("魔物介紹")
                    })
                }
        
            .navigationTitle("Monster Hunter Rise")
        }
        
        
            
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
