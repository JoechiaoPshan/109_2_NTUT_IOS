//
//  monsters_list.swift
//  demo2
//
//  Created by Joechiao on 2021/5/5.
//

import SwiftUI

struct monsters_list: View {
//    @Binding var showMon: Bool
    let monsters = ["古龍種","鳥龍種","飛龍種","牙龍種","魚龍種","獸龍種"] 
    var body: some View {
        VStack {
            
            ForEach(monsters,  id: \.self) { item in Text(item)
            
                
            }
            .padding()
            .navigationTitle("魔物種類")
        }
        
        
    }
}

struct monsters_list_Previews: PreviewProvider {
    static var previews: some View {
        monsters_list()
    }
}
