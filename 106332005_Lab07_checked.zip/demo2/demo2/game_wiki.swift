//
//  anotherPage.swift
//  demo2
//
//  Created by Joechiao on 2021/5/3.
//

import SwiftUI

struct game_wiki: View {
//    @Binding var showWiki: Bool
    
    let describtion = ["《魔物獵人 崛起》是一款由卡普空開發並發行在任天堂Switch上的動作角色扮演遊戲。","本作是繼《魔物獵人XX》後再度登陸任天堂Switch上的魔物獵人系列作品，遊戲於2021年3月26日在全球同步發售。","配合遊戲同步上市的還包括三款Amiibo，分別是隨從貓「艾路」、獵犬「加爾克」，以及新登場的封面魔物「怨虎龍」。"] 
    var body: some View {
        VStack {
            
            ForEach(describtion, id: \.self) { item in Text(item)
            
                
            }
            .padding()
            .navigationTitle("遊戲簡介")
        }
        
    }
}

struct game_wiki_Previews: PreviewProvider {
    static var previews: some View {
        game_wiki()
    }
}
