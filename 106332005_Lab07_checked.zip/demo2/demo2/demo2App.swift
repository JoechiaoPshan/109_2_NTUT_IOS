//
//  demo2App.swift
//  demo2
//
//  Created by Joechiao on 2021/5/3.
//

import SwiftUI

@main
struct demo2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
