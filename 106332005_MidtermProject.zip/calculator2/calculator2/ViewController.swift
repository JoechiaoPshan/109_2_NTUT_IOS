//
//  ViewController.swift
//  calculator2
//
//  Created by Joechiao on 2021/3/8.
//

import UIKit



class ViewController: UIViewController {
    var calculateSeq:[String] = []
    var labelSeq:[String] = []
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    @IBOutlet weak var label: UILabel!
    
    @IBOutlet weak var topLabel: UILabel!
    
    
    @IBAction func numbers(_ sender: UIButton) {
        topLabel.text = ""
        let inputNumber = Int(sender.tag - 1)
        if label.text == "0"{
            label.text! = String(inputNumber)
        }else{
            label.text! += String(inputNumber)
        }
        
        if label.text != ""{
            labelSeq.append(String(inputNumber))
        }
        if labelSeq.contains("+") == false && labelSeq.contains("-") == false && labelSeq.contains("×") == false && labelSeq.contains("÷") == false {
            if labelSeq[0] == "0" && labelSeq.count >= 2 && labelSeq[1] == "0" {
                    labelSeq.remove(at :1)
            }else if labelSeq.count >= 2 && labelSeq[1] != "0" && labelSeq[0] == "0" {
                labelSeq.remove(at: 0)
            }
        }
//        if labelSeq.count >= 2 && labelSeq[labelSeq.firstIndex(of: String(inputNumber))!-1] == "0" && labelSeq[labelSeq.firstIndex(of: String(inputNumber))!-1] == labelSeq[0] {
//                labelSeq.remove(at: 0)
                        
//                        }
        
        for i in labelSeq{
             topLabel.text! += i
        }
    }
    func calDot(){
        for i in calculateSeq{
            if i == "."{
                let num = Double((calculateSeq[(calculateSeq.firstIndex(of: i)!-1)]) + "." + (calculateSeq[(calculateSeq.firstIndex(of: i)!+1)]))!
                        calculateSeq.insert(String(num),at:(calculateSeq.firstIndex(of: i)!-1))
                        calculateSeq.removeSubrange((calculateSeq.firstIndex(of: i)!-1)...(calculateSeq.firstIndex(of: i)!+1))
                    }
        }
        
    }
    
    func removeZero(){
        
        if labelSeq.contains("."){
            let count = labelSeq.count
            if labelSeq.count > 2{
                while labelSeq[labelSeq.count - 1] == "0" || labelSeq[labelSeq.count - 1] == "."{
                    if label.text == "0"{
                        labelSeq.remove(at: labelSeq.count - 1)
                        
                    }else if labelSeq[count - label.text!.count - 1] == "."{
                        labelSeq.remove(at: labelSeq.count - 1)
                        }
                
            
        }
        
        
    }
    }
    }
    
    @IBAction func clear(_ sender: UIButton) {
        label.text = "0"
        topLabel.text = "0"
        calculateSeq = [ ]
        labelSeq = []
        
        
    }
    
    @IBAction func add(_ sender: UIButton) {
        if label.text != ""{
                   calculateSeq.append(label.text!)
        }
        if label.text == "0"{
            labelSeq.append("0")
            
        }
        
        removeZero()
        
        label.text = ""
        calculateSeq.append("+")
        topLabel.text = ""
        let last = labelSeq.count - 1
        if labelSeq[last] == "+" || labelSeq[last]  == "-" || labelSeq[last]  == "×" || labelSeq[last]  == "÷" {
            labelSeq[last] = "+"
            
        }else{
            labelSeq.append("+")
        }
        
        for i in calculateSeq{
            if i == "+"{
                while calculateSeq[calculateSeq.firstIndex(of: i)! - 1] == "+" || calculateSeq[calculateSeq.firstIndex(of: i)! - 1] == "-" || calculateSeq[calculateSeq.firstIndex(of: i)! - 1] == "×" || calculateSeq[calculateSeq.firstIndex(of: i)! - 1] == "÷" {
                    
                
                if calculateSeq[calculateSeq.firstIndex(of: i)! - 1] == "+" || calculateSeq[calculateSeq.firstIndex(of: i)! - 1] == "-" || calculateSeq[calculateSeq.firstIndex(of: i)! - 1] == "×" || calculateSeq[calculateSeq.firstIndex(of: i)! - 1] == "÷"{
                    calculateSeq.remove(at: calculateSeq.firstIndex(of: i)! - 1)
                }
                }
            }
        }
        
        for i in labelSeq{
            topLabel.text! += i
        }
        print(calculateSeq)
        print(labelSeq)
        calDot()
        
    
    }
    
    @IBAction func minus(_ sender: UIButton) {
        if label.text != ""{
                  calculateSeq.append(label.text!)
              }
        if label.text == "0"{
            labelSeq.append("0")
            
        }
        removeZero()
        
        label.text = ""
        calculateSeq.append("-")
        topLabel.text = ""
        let last = labelSeq.count - 1
        if labelSeq[last] == "+" || labelSeq[last]  == "-" || labelSeq[last]  == "×" || labelSeq[last]  == "÷" {
            labelSeq[last] = "-"
            
        }else{
            labelSeq.append("-")
        }
        for i in calculateSeq{
            if i == "-"{
                while calculateSeq[calculateSeq.firstIndex(of: i)! - 1] == "+" || calculateSeq[calculateSeq.firstIndex(of: i)! - 1] == "-" || calculateSeq[calculateSeq.firstIndex(of: i)! - 1] == "×" || calculateSeq[calculateSeq.firstIndex(of: i)! - 1] == "÷" {
                    
                
                if calculateSeq[calculateSeq.firstIndex(of: i)! - 1] == "+" || calculateSeq[calculateSeq.firstIndex(of: i)! - 1] == "-" || calculateSeq[calculateSeq.firstIndex(of: i)! - 1] == "×" || calculateSeq[calculateSeq.firstIndex(of: i)! - 1] == "÷"{
                    calculateSeq.remove(at: calculateSeq.firstIndex(of: i)! - 1)
                }
                }
            }
        }
        for i in labelSeq{
            topLabel.text! += i
        }
        calDot()
      
    }
    
    @IBAction func multiply(_ sender: UIButton) {
        if label.text != ""{
                    calculateSeq.append(label.text!)
                }
        if label.text == "0"{
            labelSeq.append("0")
            
        }
        removeZero()
        
        label.text = ""
        calculateSeq.append("×")
        topLabel.text = ""
        let last = labelSeq.count - 1
        if labelSeq[last] == "+" || labelSeq[last]  == "-" || labelSeq[last]  == "×" || labelSeq[last]  == "÷" {
            labelSeq[last] = "×"
            
        }else{
            labelSeq.append("×")
        }
        for i in calculateSeq{
            if i == "×"{
                while calculateSeq[calculateSeq.firstIndex(of: i)! - 1] == "+" || calculateSeq[calculateSeq.firstIndex(of: i)! - 1] == "-" || calculateSeq[calculateSeq.firstIndex(of: i)! - 1] == "×" || calculateSeq[calculateSeq.firstIndex(of: i)! - 1] == "÷" {
                    
                
                if calculateSeq[calculateSeq.firstIndex(of: i)! - 1] == "+" || calculateSeq[calculateSeq.firstIndex(of: i)! - 1] == "-" || calculateSeq[calculateSeq.firstIndex(of: i)! - 1] == "×" || calculateSeq[calculateSeq.firstIndex(of: i)! - 1] == "÷"{
                    calculateSeq.remove(at: calculateSeq.firstIndex(of: i)! - 1)
                }
                }
            }
        }
        for i in labelSeq{
            topLabel.text! += i
        }
        calDot()
        
    }
    
    @IBAction func divide(_ sender: UIButton) {
        if label.text != ""{
                   calculateSeq.append(label.text!)
               }
        if label.text == "0"{
            labelSeq.append("0")
            
        }
        removeZero()
        
        label.text = ""
        calculateSeq.append("÷")
        topLabel.text = ""
        let last = labelSeq.count - 1
        
        if labelSeq[last] == "+" || labelSeq[last]  == "-" || labelSeq[last]  == "×" || labelSeq[last]  == "÷" {
            labelSeq[last] = "÷"
            
        }else{
            labelSeq.append("÷")
        }
        
        for i in calculateSeq{
            if i == "÷"{
                while calculateSeq[calculateSeq.firstIndex(of: i)! - 1] == "+" || calculateSeq[calculateSeq.firstIndex(of: i)! - 1] == "-" || calculateSeq[calculateSeq.firstIndex(of: i)! - 1] == "×" || calculateSeq[calculateSeq.firstIndex(of: i)! - 1] == "÷" {
                    
                
                if calculateSeq[calculateSeq.firstIndex(of: i)! - 1] == "+" || calculateSeq[calculateSeq.firstIndex(of: i)! - 1] == "-" || calculateSeq[calculateSeq.firstIndex(of: i)! - 1] == "×" || calculateSeq[calculateSeq.firstIndex(of: i)! - 1] == "÷"{
                    calculateSeq.remove(at: calculateSeq.firstIndex(of: i)! - 1)
                }
                }
            }
        }
        for i in labelSeq{
            topLabel.text! += i
        }
        calDot()
    
       
    }
    @IBAction func dot(_ sender: UIButton) {
        
        
//        print(calculateSeq)
        
        if label.text != ""{
                   
            calculateSeq.append(label.text!)
                   
        }
       
        label.text = ""
        topLabel.text = ""

        if calculateSeq[ calculateSeq.count - 1] != "." {
            
            calculateSeq.append(".")
            
        }
        
        if labelSeq[labelSeq.count-1] != "."{
                    
            labelSeq.append(".")
        }
                
        for i in labelSeq{
            topLabel.text! += i
        }
                        
    
        }
        
    
    @IBAction func negative(_ sender: UIButton) {
        if label.text != ""{
                   calculateSeq.append(label.text!)
        }
        
        
//        if calculateSeq[calculateSeq.count - 1] == ""{
//            calculateSeq.remove(at: calculateSeq.count - 1)
//        }
        calDot()
        
        print(calculateSeq)

        topLabel.text = ""
        let num = Double(calculateSeq[0])! * -1
        label.text = String(num)
        
        
//        calculateSeq[calculateSeq.count-1] = String(Double(calculateSeq[calculateSeq.count-1])! * -1)
        labelSeq.insert("-", at: 0)
        for i in labelSeq{
            if i == "-"{
                if labelSeq[labelSeq.firstIndex(of:i)!+1] == "-"{
                    labelSeq.remove(at:labelSeq.firstIndex(of:i)!)
                }
            }
            topLabel.text! += i
        }
        

    }
    
    @IBAction func percent(_ sender: UIButton) {
        topLabel.text = ""
        labelSeq.removeLast(label.text!.count)
        let num = Double(label.text!)
        label.text = String(num! * 0.01)
        labelSeq.append(label.text!)
       
        for i in labelSeq{
            topLabel.text! += i
        }
        
        
        
    }
    
    @IBAction func ans(_ sender: UIButton) {
        if label.text != nil{
                    calculateSeq.append(label.text!)
                }
        topLabel.text = ""
        calDot()
        removeZero()
        
        
        while calculateSeq.count > 1{
        
            for i in calculateSeq{
                if i == "." || i == "×" || i == "÷" || i == "+" || i == "-" {
                    if Double(calculateSeq[(calculateSeq.firstIndex(of: i)!-1)]) == nil{
                        calculateSeq.insert("0", at: 0)
                        
                    }
                }
                
                if i == "×"{
                    let num = Double(calculateSeq[(calculateSeq.firstIndex(of: i)!-1)])! * Double(calculateSeq[(calculateSeq.firstIndex(of: i)!+1)])!
                    calculateSeq.insert(String(num),at:(calculateSeq.firstIndex(of: i)!-1))
                    calculateSeq.removeSubrange((calculateSeq.firstIndex(of: i)!-1)...(calculateSeq.firstIndex(of: i)!+1))
                    
                }else if i == "÷"{
                    var num = Double(calculateSeq[(calculateSeq.firstIndex(of: i)!-1)])! / Double(calculateSeq[(calculateSeq.firstIndex(of: i)!+1)])!
                    if Double(calculateSeq[(calculateSeq.firstIndex(of: i)!+1)])! == 0{
                        num = 0
                    }
                    calculateSeq.insert(String(num),at:(calculateSeq.firstIndex(of: i)!-1))
                    calculateSeq.removeSubrange((calculateSeq.firstIndex(of: i)!-1)...(calculateSeq.firstIndex(of: i)!+1))
                }
            }
                
            if  calculateSeq.contains("×") == false && calculateSeq.contains("÷") == false{
                
                for i in calculateSeq{
                    if i == "+"{
                        let num = Double(calculateSeq[(calculateSeq.firstIndex(of: i)!-1)])! + Double(calculateSeq[(calculateSeq.firstIndex(of: i)!+1)])!
                        
                        calculateSeq.insert(String(num),at:(calculateSeq.firstIndex(of: i)!-1))
                        calculateSeq.removeSubrange((calculateSeq.firstIndex(of: i)!-1)...(calculateSeq.firstIndex(of: i)!+1))
                        
                    }else if i == "-"{
                        let num = Double(calculateSeq[(calculateSeq.firstIndex(of: i)!-1)])! - Double(calculateSeq[(calculateSeq.firstIndex(of: i)!+1)])!
                        
                        calculateSeq.insert(String(num),at:(calculateSeq.firstIndex(of: i)!-1))

                        calculateSeq.removeSubrange((calculateSeq.firstIndex(of: i)!-1)...(calculateSeq.firstIndex(of: i)!+1))
                    
                }
            }
        }
        }
        
        
        if calculateSeq[0] == "0.0"{
            
            label.text = "0"
        }else{
            
        
        while calculateSeq[0].last == "0" || calculateSeq[0].last == "."{
            calculateSeq[0].removeLast()
        }
        label.text = calculateSeq[0]
            
        }
        for i in labelSeq{
                        topLabel.text! += i
                    }
                    topLabel.text! += "="

            
        
    
        }
                        }
   
       


        


