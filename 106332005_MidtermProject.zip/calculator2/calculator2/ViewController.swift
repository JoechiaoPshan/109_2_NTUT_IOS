//
//  ViewController.swift
//  calculator2
//
//  Created by Joechiao on 2021/3/8.
//

import UIKit



class ViewController: UIViewController {
    var calculateSeq:[String] = []
    var labelSeq:[String] = []
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    @IBOutlet weak var label: UILabel!
    
    @IBOutlet weak var topLabel: UILabel!
    
    
    @IBAction func numbers(_ sender: UIButton) {
        topLabel.text = ""
        let inputNumber = Int(sender.tag - 1)
        if label.text == "0"{
            label.text! = String(inputNumber)
        }else{
            label.text! += String(inputNumber)
        }
        
        if label.text != "0"{
            labelSeq.append(String(inputNumber))
        }
        
        for i in labelSeq{
           
                topLabel.text! += i
                
        }

    }
    func calDot(){
        for i in calculateSeq{
            if i == "."{
                let num = Double((calculateSeq[(calculateSeq.firstIndex(of: i)!-1)]) + "." + (calculateSeq[(calculateSeq.firstIndex(of: i)!+1)]))!
                        calculateSeq.insert(String(num),at:(calculateSeq.firstIndex(of: i)!-1))
                        calculateSeq.removeSubrange((calculateSeq.firstIndex(of: i)!-1)...(calculateSeq.firstIndex(of: i)!+1))
                    }
        }
        
    }
    
    @IBAction func clear(_ sender: UIButton) {
        label.text = "0"
        topLabel.text = "0"
        calculateSeq = [ ]
        labelSeq = []
        
        
    }
    
    @IBAction func add(_ sender: UIButton) {
        if label.text != ""{
                   calculateSeq.append(label.text!)
        }
        if label.text == "0"{
            labelSeq.append("0")
            
        }
        
        label.text = ""
        calculateSeq.append("+")
        topLabel.text = ""
        let last = labelSeq.count - 1
        if labelSeq[last] == "+" || labelSeq[last]  == "-" || labelSeq[last]  == "×" || labelSeq[last]  == "÷" {
            labelSeq[last] = "+"
            
        }else{
            labelSeq.append("+")
        }
        
        for i in calculateSeq{
            if i == "+"{
                while calculateSeq[calculateSeq.firstIndex(of: i)! - 1] == "+" || calculateSeq[calculateSeq.firstIndex(of: i)! - 1] == "-" || calculateSeq[calculateSeq.firstIndex(of: i)! - 1] == "×" || calculateSeq[calculateSeq.firstIndex(of: i)! - 1] == "÷" {
                    
                
                if calculateSeq[calculateSeq.firstIndex(of: i)! - 1] == "+" || calculateSeq[calculateSeq.firstIndex(of: i)! - 1] == "-" || calculateSeq[calculateSeq.firstIndex(of: i)! - 1] == "×" || calculateSeq[calculateSeq.firstIndex(of: i)! - 1] == "÷"{
                    calculateSeq.remove(at: calculateSeq.firstIndex(of: i)! - 1)
                }
                }
            }
        }
        
        for i in labelSeq{
            topLabel.text! += i
        }
        print(calculateSeq)
        calDot()
    
    }
    
    @IBAction func minus(_ sender: UIButton) {
        if label.text != ""{
                  calculateSeq.append(label.text!)
              }
        if label.text == "0"{
            labelSeq.append("0")
            
        }
        
        label.text = ""
        calculateSeq.append("-")
        topLabel.text = ""
        let last = labelSeq.count - 1
        if labelSeq[last] == "+" || labelSeq[last]  == "-" || labelSeq[last]  == "×" || labelSeq[last]  == "÷" {
            labelSeq[last] = "-"
            
        }else{
            labelSeq.append("-")
        }
        for i in calculateSeq{
            if i == "-"{
                while calculateSeq[calculateSeq.firstIndex(of: i)! - 1] == "+" || calculateSeq[calculateSeq.firstIndex(of: i)! - 1] == "-" || calculateSeq[calculateSeq.firstIndex(of: i)! - 1] == "×" || calculateSeq[calculateSeq.firstIndex(of: i)! - 1] == "÷" {
                    
                
                if calculateSeq[calculateSeq.firstIndex(of: i)! - 1] == "+" || calculateSeq[calculateSeq.firstIndex(of: i)! - 1] == "-" || calculateSeq[calculateSeq.firstIndex(of: i)! - 1] == "×" || calculateSeq[calculateSeq.firstIndex(of: i)! - 1] == "÷"{
                    calculateSeq.remove(at: calculateSeq.firstIndex(of: i)! - 1)
                }
                }
            }
        }
        for i in labelSeq{
            topLabel.text! += i
        }
        calDot()
      
    }
    
    @IBAction func multiply(_ sender: UIButton) {
        if label.text != ""{
                    calculateSeq.append(label.text!)
                }
        if label.text == "0"{
            labelSeq.append("0")
            
        }
        
        label.text = ""
        calculateSeq.append("×")
        topLabel.text = ""
        let last = labelSeq.count - 1
        if labelSeq[last] == "+" || labelSeq[last]  == "-" || labelSeq[last]  == "×" || labelSeq[last]  == "÷" {
            labelSeq[last] = "×"
            
        }else{
            labelSeq.append("×")
        }
        for i in calculateSeq{
            if i == "×"{
                while calculateSeq[calculateSeq.firstIndex(of: i)! - 1] == "+" || calculateSeq[calculateSeq.firstIndex(of: i)! - 1] == "-" || calculateSeq[calculateSeq.firstIndex(of: i)! - 1] == "×" || calculateSeq[calculateSeq.firstIndex(of: i)! - 1] == "÷" {
                    
                
                if calculateSeq[calculateSeq.firstIndex(of: i)! - 1] == "+" || calculateSeq[calculateSeq.firstIndex(of: i)! - 1] == "-" || calculateSeq[calculateSeq.firstIndex(of: i)! - 1] == "×" || calculateSeq[calculateSeq.firstIndex(of: i)! - 1] == "÷"{
                    calculateSeq.remove(at: calculateSeq.firstIndex(of: i)! - 1)
                }
                }
            }
        }
        for i in labelSeq{
            topLabel.text! += i
        }
        calDot()
        
    }
    
    @IBAction func divide(_ sender: UIButton) {
        if label.text != ""{
                   calculateSeq.append(label.text!)
               }
        if label.text == "0"{
            labelSeq.append("0")
            
        }
        
        label.text = ""
        calculateSeq.append("÷")
        topLabel.text = ""
        let last = labelSeq.count - 1
        
        if labelSeq[last] == "+" || labelSeq[last]  == "-" || labelSeq[last]  == "×" || labelSeq[last]  == "÷" {
            labelSeq[last] = "÷"
            
        }else{
            labelSeq.append("÷")
        }
        
        for i in calculateSeq{
            if i == "÷"{
                while calculateSeq[calculateSeq.firstIndex(of: i)! - 1] == "+" || calculateSeq[calculateSeq.firstIndex(of: i)! - 1] == "-" || calculateSeq[calculateSeq.firstIndex(of: i)! - 1] == "×" || calculateSeq[calculateSeq.firstIndex(of: i)! - 1] == "÷" {
                    
                
                if calculateSeq[calculateSeq.firstIndex(of: i)! - 1] == "+" || calculateSeq[calculateSeq.firstIndex(of: i)! - 1] == "-" || calculateSeq[calculateSeq.firstIndex(of: i)! - 1] == "×" || calculateSeq[calculateSeq.firstIndex(of: i)! - 1] == "÷"{
                    calculateSeq.remove(at: calculateSeq.firstIndex(of: i)! - 1)
                }
                }
            }
        }
        for i in labelSeq{
            topLabel.text! += i
        }
        calDot()
    
       
    }
    @IBAction func dot(_ sender: UIButton) {
        
        
//        print(calculateSeq)
        
        if label.text != ""{
                   calculateSeq.append(label.text!)
                   
               }
       
        label.text = ""
        topLabel.text = ""

        if calculateSeq[ calculateSeq.count - 1] != "." {
            
            calculateSeq.append(".")
            
        }
        
                if labelSeq[labelSeq.count-1] != "."{
                    labelSeq.append(".")
                    }
                
        for i in labelSeq{
            topLabel.text! += i
        }
                        
    
        }
        
    
    @IBAction func negative(_ sender: UIButton) {
                
        topLabel.text = ""
        let num = Double(label.text!)
        label.text = String(num! * -1)
//        calculateSeq[calculateSeq.count-1] = String(Double(calculateSeq[calculateSeq.count-1])! * -1)
        labelSeq.insert("-", at: 0)
        for i in labelSeq{
            if i == "-"{
                if labelSeq[labelSeq.firstIndex(of:i)!+1] == "-"{
                    labelSeq.remove(at:labelSeq.firstIndex(of:i)!)
                }
            }
            topLabel.text! += i
        }
       
    
    }
    
    @IBAction func percent(_ sender: UIButton) {
        topLabel.text = ""
        let num = Double(label.text!)
        label.text = String(num! * 0.01)
        topLabel.text = label.text
        
        
    }
    
    @IBAction func ans(_ sender: UIButton) {
        if label.text != nil{
                    calculateSeq.append(label.text!)
                }
        calDot()
        
        while calculateSeq.count > 1{
        
            for i in calculateSeq{
                if i == "." || i == "×" || i == "÷" || i == "+" || i == "-" {
                    if Double(calculateSeq[(calculateSeq.firstIndex(of: i)!-1)]) == nil{
                        calculateSeq.insert("0", at: 0)
                        
                    }
                }
                
                if i == "×"{
                    let num = Double(calculateSeq[(calculateSeq.firstIndex(of: i)!-1)])! * Double(calculateSeq[(calculateSeq.firstIndex(of: i)!+1)])!
                    calculateSeq.insert(String(num),at:(calculateSeq.firstIndex(of: i)!-1))
                    calculateSeq.removeSubrange((calculateSeq.firstIndex(of: i)!-1)...(calculateSeq.firstIndex(of: i)!+1))
                    
                }else if i == "÷"{
                    var num = Double(calculateSeq[(calculateSeq.firstIndex(of: i)!-1)])! / Double(calculateSeq[(calculateSeq.firstIndex(of: i)!+1)])!
                    if Double(calculateSeq[(calculateSeq.firstIndex(of: i)!+1)])! == 0{
                        num = 0
                    }
                    calculateSeq.insert(String(num),at:(calculateSeq.firstIndex(of: i)!-1))
                    calculateSeq.removeSubrange((calculateSeq.firstIndex(of: i)!-1)...(calculateSeq.firstIndex(of: i)!+1))
                }
            }
                
            if  calculateSeq.contains("×") == false && calculateSeq.contains("÷") == false{
                
                for i in calculateSeq{
                    if i == "+"{
                        let num = Double(calculateSeq[(calculateSeq.firstIndex(of: i)!-1)])! + Double(calculateSeq[(calculateSeq.firstIndex(of: i)!+1)])!
                        
                        calculateSeq.insert(String(num),at:(calculateSeq.firstIndex(of: i)!-1))
                        calculateSeq.removeSubrange((calculateSeq.firstIndex(of: i)!-1)...(calculateSeq.firstIndex(of: i)!+1))
                        
                    }else if i == "-"{
                        let num = Double(calculateSeq[(calculateSeq.firstIndex(of: i)!-1)])! - Double(calculateSeq[(calculateSeq.firstIndex(of: i)!+1)])!
                        
                        calculateSeq.insert(String(num),at:(calculateSeq.firstIndex(of: i)!-1))

                        calculateSeq.removeSubrange((calculateSeq.firstIndex(of: i)!-1)...(calculateSeq.firstIndex(of: i)!+1))
                    
                }
            }
        }
        }
        

               label.text = calculateSeq[0]
               topLabel.text! += "=" + calculateSeq[0]


        }
                    
            
        
    
        }
   
       


        


