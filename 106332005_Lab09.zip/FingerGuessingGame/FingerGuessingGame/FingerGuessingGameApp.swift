//
//  FingerGuessingGameApp.swift
//  FingerGuessingGame
//
//  Created by Joechiao on 2021/5/19.
//

import SwiftUI

@main
struct FingerGuessingGameApp: App {
    var body: some Scene {
        WindowGroup {
            GameView()
        }
    }
}
