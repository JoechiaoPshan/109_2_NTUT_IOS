//
//  GameView.swift
//  FingerGuessingGame
//
//  Created by Joechiao on 2021/5/19.
//

import SwiftUI

struct GameView: View {
    @StateObject var gameViewModel = GameViewModel()
    @State private var resultText = "請按\"出拳\"開始猜拳"
    
    var body: some View {
        VStack{
            HStack {
                VStack {
                    Text("玩家: ")
                        .padding()
                    Text("電腦: ")
                }
                .padding()
                VStack {
                    Image("\(gameViewModel.playerGesture)")
                        .resizable()
                        .frame(width: 50, height: 50, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                        .padding()
                    Image("\(gameViewModel.computerGesture)")
                        .resizable()
                        .frame(width: 50, height: 50, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                }
                VStack{
                    Text("\(gameViewModel.playerGesture)")
                        .padding()
                    Text("\(gameViewModel.computerGesture)")
                    
                }
                
            }
            .padding()
            ZStack {
                
                
                
                Image("paperscissorstone")
                    .resizable()
                    .frame(width: 200, height: 170, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                Button(action: {
                    gameViewModel.play()
                    
                    resultText = gameViewModel.Result()
                    
                }
                , label: {
                    Text("出拳")
                })
            }
            
            HStack {
                Text("結果: ")
                
                Text("\(resultText)")
                    .foregroundColor(Color.red)
                
            }
            
            
            
            
        }
        
        
        
        
        
    }
}
struct GameView_Previews: PreviewProvider {
    static var previews: some View {
        GameView()
    }
}
