//
//  GameViewModel.swift
//  FingerGuessingGame
//
//  Created by Joechiao on 2021/5/19.
//

import SwiftUI

class GameViewModel: ObservableObject{
    @Published var rockPaperScissors = ["stone","scissor","paper"]
    @Published var playerGesture = "stone"
    @Published var computerGesture = "stone"
    @Published var result: GameResult?
    
    enum GameResult{
        case win
        case lose
        case even
    }
    func play(){
        rockPaperScissors.shuffle()
        let playerIndex = Int.random(in: 0...2)
        let computerIndex = Int.random(in: 0...2)
        playerGesture = rockPaperScissors[playerIndex]
        computerGesture = rockPaperScissors[computerIndex]
        result = checkResult()
    }
    func checkResult() -> GameResult{
        if playerGesture == "stone" && computerGesture == "scissor" {
            return .win
            
        }else if playerGesture == computerGesture{
            return .even
            
        }else if playerGesture == "stone" && computerGesture == "paper"{
            return .lose
        }else if playerGesture == "scissor" && computerGesture == "stone"{
            return.lose
        }else if playerGesture == "scissor" && computerGesture == "paper"{
            return.win
        }else if playerGesture == "paper" && computerGesture == "stone"{
            return.win
        }else if playerGesture == "paper" && computerGesture == "scissor"{
            return.lose
        }else{
            return .even
        }
        
    }
    func Result() -> String{
        if result == .win{
            return "贏了"
        }else if result == .lose{
            return "輸了"
        }else{
           return "平手"
        }
    }
}
