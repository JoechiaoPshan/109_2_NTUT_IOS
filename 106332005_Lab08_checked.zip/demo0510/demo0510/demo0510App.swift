//
//  demo0510App.swift
//  demo0510
//
//  Created by Joechiao on 2021/5/10.
//

import SwiftUI

@main
struct demo0510App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
