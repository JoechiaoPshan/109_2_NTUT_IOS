//
//  ContentView.swift
//  demo0510
//
//  Created by Joechiao on 2021/5/10.
//

import SwiftUI

struct ContentView: View {
    @State private var cuteValue: CGFloat = 0
    @State private var frameSize: CGFloat = 300
    @State private var isPet = false
    @State private var age = 0
    @State private var birthday = Date()
    @State private var inputText = ""
    @State private var showAlert = false
    var pet = ""
    var catList = ["blue cat", "orange cat", "white cat", "black cat"]
    @State private var selectedIndex = 0
    var answer = Int.random(in: 0...100)
    var body: some View {
        VStack{
            Image("Image")
                .resizable()
                .scaledToFill()
                .frame(width: frameSize, height: frameSize)
            Toggle(isOn: $isPet, label: {
                Text("有養貓嗎: ")
            })
            Stepper("幾歲? \(age)", value: $age)
            HStack{
                Text("cuteness: ")
                Slider(value: $cuteValue, in: 0...100)
                let cuteness = String(Int(Float(cuteValue)))
                Text(cuteness)
            }
            DatePicker("生日是哪天?", selection: $birthday, displayedComponents:[.date])
            Picker(selection: $selectedIndex, label: Text("哪種顏色的貓?")){
                ForEach(catList.indices) {
                    (index) in
                    Text(catList[index])
                }
            }
            
            TextField("輸入名字", text: $inputText)
                .textFieldStyle(RoundedBorderTextFieldStyle())
            Button(action: {
                    showAlert = true
                
            }, label: {
                Text("GO")
            })
            
        }
        .padding()
        .alert(isPresented: $showAlert , content: {
            return Alert(title: Text("cat is cute"))
        })
        
    }
    

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
}
